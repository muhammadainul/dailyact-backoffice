-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 15, 2018 at 05:02 AM
-- Server version: 5.7.20
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `starter_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `apps`
--

CREATE TABLE `apps` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secret_key` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apps`
--

INSERT INTO `apps` (`id`, `name`, `secret_key`, `created_date`, `last_activity`) VALUES
(1, 'web', '827ccb0eea8a706c4c34a16891f84e7b', '2018-01-15 04:29:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `string_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `string_id`, `title`, `content`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, '123', 'Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?', 'Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\r\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\r\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\r\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\r\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.', 1, '2018-01-15 04:42:07', NULL, NULL),
(2, '1234', 'Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?', 'Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\r\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\r\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\r\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\r\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.', 1, '2018-01-15 04:54:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SequelizeMeta`
--

CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SequelizeMeta`
--

INSERT INTO `SequelizeMeta` (`name`) VALUES
('20170906-initial_migration.js');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `apps_id` int(11) NOT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_type` varchar(50) NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `token_code` varchar(255) NOT NULL,
  `refresh_token` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expired_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `apps_id`, `device_id`, `device_type`, `ip`, `token_code`, `refresh_token`, `created_date`, `expired_date`) VALUES
(1, 1, '', '', '::1', 'I0I8hnpzSIX69dxrL4C0njoMZjCXDPUZ', 'Fx9XRZziCcaJxYvLRSHVx2hcXwbp40uc', '2018-01-15 04:30:02', '2018-01-16 04:59:48');

-- --------------------------------------------------------

--
-- Table structure for table `token_log`
--

CREATE TABLE `token_log` (
  `id` int(11) NOT NULL,
  `token_id` int(11) NOT NULL,
  `user_agent` text,
  `path` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `request` text NOT NULL,
  `response` text,
  `final_action` varchar(255) DEFAULT NULL,
  `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_date` timestamp NULL DEFAULT NULL,
  `memory_usage` double(18,8) DEFAULT NULL,
  `time_elapse` double(18,8) DEFAULT NULL,
  `api_version` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `token_log`
--

INSERT INTO `token_log` (`id`, `token_id`, `user_agent`, `path`, `method`, `request`, `response`, `final_action`, `start_date`, `end_date`, `memory_usage`, `time_elapse`, `api_version`) VALUES
(1, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:47:03', NULL, NULL, NULL, NULL),
(2, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:47:03', NULL, NULL, NULL, NULL),
(3, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:48:06', NULL, NULL, NULL, NULL),
(4, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:48:06', NULL, NULL, NULL, NULL),
(5, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:49:05', NULL, NULL, NULL, NULL),
(6, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', NULL, '', '2018-01-15 04:49:21', NULL, NULL, NULL, NULL),
(7, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:49:21', '2018-01-15 04:50:37', -113448.00000000, 0.02100000, '0.0.1-beta'),
(8, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:49:21', '2018-01-15 04:51:35', -125080.00000000, 0.02000000, '0.0.1-beta'),
(9, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"code\":500,\"message\":\"world is not defined\"}]', 'error', '2018-01-15 04:51:43', '2018-01-15 04:51:44', 7853952.00000000, 0.14200000, '0.0.1-beta'),
(10, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"code\":500,\"message\":\"world is not defined\"}]', 'error', '2018-01-15 04:51:43', '2018-01-15 04:51:51', 897024.00000000, 0.02600000, '0.0.1-beta'),
(11, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '{\"data\":[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null}],\"hello\":\"world\"}', 'success', '2018-01-15 04:51:59', '2018-01-15 04:52:00', 7808048.00000000, 0.17900000, '0.0.1-beta'),
(12, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '{\"data\":[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null}],\"hello\":\"world eka is here\"}', 'success', '2018-01-15 04:52:25', '2018-01-15 04:52:25', 7845264.00000000, 0.14700000, '0.0.1-beta'),
(13, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:53:17', '2018-01-15 04:53:17', 4338160.00000000, 0.15300000, '0.0.1-beta'),
(14, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null},{\"id\":2,\"string_id\":\"1234\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:54:09.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:53:17', '2018-01-15 04:54:13', 11480.00000000, 0.02600000, '0.0.1-beta'),
(15, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '{}', 'success', '2018-01-15 04:56:24', '2018-01-15 04:56:24', 7507624.00000000, 0.14800000, '0.0.1-beta'),
(16, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '{}', 'success', '2018-01-15 04:56:44', '2018-01-15 04:56:44', 7486376.00000000, 0.16200000, '0.0.1-beta'),
(17, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '{}', 'success', '2018-01-15 04:57:32', '2018-01-15 04:57:33', 7465088.00000000, 0.14600000, '0.0.1-beta'),
(18, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null},{\"id\":2,\"string_id\":\"1234\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:54:09.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:57:53', '2018-01-15 04:57:54', 7874464.00000000, 0.16400000, '0.0.1-beta'),
(19, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null},{\"id\":2,\"string_id\":\"1234\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:54:09.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:58:25', '2018-01-15 04:58:25', 7561968.00000000, 0.14800000, '0.0.1-beta'),
(20, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null},{\"id\":2,\"string_id\":\"1234\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:54:09.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:58:47', '2018-01-15 04:58:47', 7605800.00000000, 0.14200000, '0.0.1-beta'),
(21, 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '/api/news/list', 'POST', '{}', '[{\"id\":1,\"string_id\":\"123\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:42:07.000Z\",\"updated_by\":null,\"updated_date\":null},{\"id\":2,\"string_id\":\"1234\",\"title\":\"Inmensae subtilitatis, obscuris et malesuada fames. Ambitioni dedisse scripsisse iudicaretur. Ut enim ad minim veniam, quis nostrud exercitation. At nos hinc posthac, sitientis piros Afros. Quo usque tandem abutere, Catilina, patientia nostra 2?\",\"content\":\"Ut enim ad minim veniam, quis nostrud exercitation. Donec sed odio operae, eu vulputate felis rhoncus. Magna pars studiorum, prodita quaerimus. Idque Caesaris facere voluntate liceret: sese habere. Plura mihi bona sunt, inclinet, amari petere vellent.\\r\\nFabio vel iudice vincam, sunt in culpa qui officia. Salutantibus vitae elit libero, a pharetra augue. Nihilne te nocturnum praesidium Palati, nihil urbis vigiliae.\\r\\nVivamus sagittis lacus vel augue laoreet rutrum faucibus. Tityre, tu patulae recubans sub tegmine fagi dolor. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Sed haec quis possit intrepidus aestimare tellus. Excepteur sint obcaecat cupiditat non proident culpa.\\r\\nQui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna. Phasellus laoreet lorem vel dolor tempus vehicula.\\r\\nCum sociis natoque penatibus et magnis dis parturient. Ambitioni dedisse scripsisse iudicaretur. Petierunt uti sibi concilium totius Galliae in diem certam indicere.\",\"created_by\":1,\"created_date\":\"2018-01-15T04:54:09.000Z\",\"updated_by\":null,\"updated_date\":null}]', 'success', '2018-01-15 04:59:48', '2018-01-15 04:59:48', 7567224.00000000, 0.15000000, '0.0.1-beta');

-- --------------------------------------------------------

--
-- Table structure for table `token_profile`
--

CREATE TABLE `token_profile` (
  `token_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `token_profile`
--

INSERT INTO `token_profile` (`token_id`, `user_id`, `admin_id`, `created_date`, `last_activity`) VALUES
(1, NULL, NULL, '2018-01-15 04:30:02', '2018-01-15 04:59:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apps`
--
ALTER TABLE `apps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `SequelizeMeta`
--
ALTER TABLE `SequelizeMeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `SequelizeMeta_name_unique` (`name`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token_log`
--
ALTER TABLE `token_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token_profile`
--
ALTER TABLE `token_profile`
  ADD PRIMARY KEY (`token_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apps`
--
ALTER TABLE `apps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `token_log`
--
ALTER TABLE `token_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
